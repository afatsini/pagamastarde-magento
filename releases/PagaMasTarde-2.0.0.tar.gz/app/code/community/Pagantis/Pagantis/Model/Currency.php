<?php

/**
 * @package    Pagantis_Pagantis
 * @copyright  Copyright (c) 2015 Yameveo (http://www.yameveo.com)
 * @author	   Yameveo <yameveo@yameveo.com>
 * @link	   http://www.yameveo.com
 */

class Pagantis_Pagantis_Model_Currency
{

    const EUR = 'EUR';
    const USD = 'USD';
    const GBP = 'GBP';

}
